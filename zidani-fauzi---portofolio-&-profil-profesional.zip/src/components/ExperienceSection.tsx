import React from 'react';
import { EXPERIENCES } from '../data/profileData';
import { CheckCircle2, Calendar } from 'lucide-react';

export const ExperienceSection: React.FC = () => {
  return (
    <section id="pengalaman" className="py-10 border-b border-zinc-850">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 space-y-8">
        <div>
          <h2 className="text-xl font-bold text-zinc-100">
            Pengalaman & Rekam Jejak
          </h2>
          <p className="text-xs text-zinc-400 mt-1">
            Riwayat di bidang konten kreatif digital, kepengurusan organisasi mahasiswa, serta kepanitiaan logistik tingkat jurusan hingga regional Jawa Timur.
          </p>
        </div>

        <div className="space-y-6">
          {EXPERIENCES.map((exp) => (
            <div
              key={exp.id}
              className="p-5 sm:p-6 rounded-xl bg-zinc-900/40 border border-zinc-800/80 space-y-4 hover:border-zinc-700/80 transition-colors"
            >
              {/* Header */}
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                <div className="space-y-0.5">
                  <div className="text-[11px] font-semibold text-amber-400 uppercase tracking-wider">
                    {exp.category}
                  </div>
                  <h3 className="text-base sm:text-lg font-bold text-zinc-100">
                    {exp.role}
                  </h3>
                  <div className="text-xs text-zinc-300 font-medium">
                    {exp.organization}
                  </div>
                </div>

                <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-zinc-950 border border-zinc-800 text-xs font-mono text-zinc-400 shrink-0">
                  <Calendar className="w-3 h-3 text-amber-400" />
                  <span>{exp.period}</span>
                </div>
              </div>

              {/* Description */}
              <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed">
                {exp.description}
              </p>

              {/* Key Highlights / Achievements */}
              <div className="space-y-2 pt-2 border-t border-zinc-800/60">
                <div className="text-xs font-semibold text-zinc-400">
                  Pencapaian & Tanggung Jawab Utama:
                </div>
                <div className="space-y-1.5">
                  {exp.achievements.map((item, idx) => (
                    <div key={idx} className="flex items-start gap-2.5 text-xs text-zinc-300">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      <span className="leading-relaxed">{item}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-1.5 pt-2 border-t border-zinc-800/40">
                {exp.skills.map((skill, i) => (
                  <span
                    key={i}
                    className="px-2 py-0.5 rounded bg-zinc-950 border border-zinc-850 text-[11px] text-zinc-400"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
