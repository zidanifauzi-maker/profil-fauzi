import React from 'react';
import { SKILLS_DATA } from '../data/profileData';
import { Sparkles, FileSpreadsheet, Brain, Mic, Clock, MessageSquare, Edit3, Boxes, Lightbulb } from 'lucide-react';

export const SkillsSection: React.FC = () => {
  const getSoftSkillIcon = (name: string) => {
    switch (name) {
      case 'Resource Management':
        return <Boxes className="w-4 h-4 text-emerald-400 shrink-0" />;
      case 'Skill Kreatif':
        return <Lightbulb className="w-4 h-4 text-amber-400 shrink-0" />;
      case 'Critical Thinking':
        return <Brain className="w-4 h-4 text-sky-400 shrink-0" />;
      case 'Public Speaking':
        return <Mic className="w-4 h-4 text-rose-400 shrink-0" />;
      case 'Time Management':
        return <Clock className="w-4 h-4 text-blue-400 shrink-0" />;
      case 'Communication':
        return <MessageSquare className="w-4 h-4 text-purple-400 shrink-0" />;
      case 'Basic Editing':
      default:
        return <Edit3 className="w-4 h-4 text-amber-400 shrink-0" />;
    }
  };

  return (
    <section id="keahlian" className="py-10 border-b border-zinc-850">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 space-y-8">
        <div>
          <h2 className="text-xl font-bold text-zinc-100">
            Keahlian & Keterampilan
          </h2>
          <p className="text-xs text-zinc-400 mt-1">
            Keterampilan teknis terapan (hardskill) serta kompetensi interpersonal & organisasi (softskill).
          </p>
        </div>

        {/* Hardskills Cards */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 uppercase tracking-wider">
            <FileSpreadsheet className="w-4 h-4" />
            <span>Keahlian Teknis (Hardskill)</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {SKILLS_DATA.hardskills.map((skill, idx) => (
              <div
                key={idx}
                className="p-4 rounded-xl bg-zinc-900/40 border border-zinc-800/80 space-y-1.5 hover:border-zinc-750 transition-colors"
              >
                <div className="text-sm font-bold text-zinc-100 flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />
                  <span>{skill.title}</span>
                </div>
                <p className="text-xs text-zinc-300 leading-relaxed">
                  {skill.desc}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Softskills */}
        <div className="space-y-4 pt-2">
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 uppercase tracking-wider">
            <Sparkles className="w-4 h-4" />
            <span>Keterampilan Interpersonal (Softskill)</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {SKILLS_DATA.softskills.map((soft, i) => (
              <div
                key={i}
                className="p-3.5 rounded-xl bg-zinc-900/50 border border-zinc-800/80 space-y-1 hover:border-zinc-700 transition-colors"
              >
                <div className="flex items-center gap-2 font-bold text-xs text-zinc-100">
                  {getSoftSkillIcon(soft.name)}
                  <span>{soft.name}</span>
                </div>
                <p className="text-[11px] text-zinc-400 leading-normal">
                  {soft.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
