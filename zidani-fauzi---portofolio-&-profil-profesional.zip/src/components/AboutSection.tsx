import React from 'react';

export const AboutSection: React.FC = () => {
  return (
    <section id="tentang" className="py-10 border-b border-zinc-850">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 space-y-4">
        <h2 className="text-xl font-bold text-zinc-100">
          Tentang Saya
        </h2>
        
        <div className="space-y-3 text-sm text-zinc-300 leading-relaxed">
          <p>
            Saya adalah mahasiswa <strong>Hubungan Internasional Universitas Jember</strong> yang aktif dalam manajemen logistik kepanitiaan, pemberdayaan ekonomi kreatif organisasi, serta industri kreatif pembuatan konten digital.
          </p>
          <p>
            Dalam kepanitiaan dan organisasi, saya memiliki rekam jejak panjang sebagai <strong>Staf Logistik</strong> di berbagai kegiatan berskala jurusan hingga se-Jawa Timur—seperti <strong>IRL 2026</strong>, <strong>Social Responsibility 2026</strong> (volunteer panti jompo, TPQ, dan bersih pantai), <strong>IRegeneration 2026</strong> (ospek jurusan), <strong>MUNSchool</strong> (simulasi sidang umum PBB), <strong>HI CUP 2025</strong> (turnamen basket se-Jatim), dan <strong>IRL 2025</strong>. Saya bertanggung jawab atas alur pengadaan barang (beli, sewa, pinjam), inventarisasi, pengoperasian alat teknis, serta pengembalian barang secara tertib.
          </p>
          <p>
            Pada Divisi Ekonomi Kreatif HIMAHI, saya mengoperasikan unit usaha <strong>IR Printing</strong> yang sukses meraih ratusan pesanan dan omset Rp 4.000.000,-. Di ranah digital, saya dipercaya sebagai <strong>Konten Kreator & Ambassador Bstation</strong> dengan 3 kanal aktif, serta mengeksplorasi logika komputasional melalui pembuatan game sederhana di <strong>Scratch MIT</strong>.
          </p>
        </div>
      </div>
    </section>
  );
};
