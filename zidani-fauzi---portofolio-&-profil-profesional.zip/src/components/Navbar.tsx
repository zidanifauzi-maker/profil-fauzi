import React from 'react';
import { Moon, Sun, Mail } from 'lucide-react';

interface NavbarProps {
  isDark: boolean;
  onToggleTheme: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ isDark, onToggleTheme }) => {
  return (
    <header className="sticky top-0 z-30 w-full backdrop-blur-md bg-zinc-950/80 border-b border-zinc-850/80 transition-colors">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-6">
        {/* Zone 1: Simple Wordmark */}
        <a
          href="#"
          className="text-base font-bold tracking-tight text-zinc-100 hover:text-amber-400 transition-colors whitespace-nowrap"
        >
          Zidani Fauzi
        </a>

        {/* Zone 2: Nav links */}
        <nav className="hidden sm:flex items-center gap-6 text-sm text-zinc-400">
          <a href="#tentang" className="hover:text-zinc-100 transition-colors">
            Tentang
          </a>
          <a href="#pengalaman" className="hover:text-zinc-100 transition-colors">
            Pengalaman
          </a>
          <a href="#karya" className="hover:text-zinc-100 transition-colors">
            Karya & Kanal
          </a>
          <a href="#keahlian" className="hover:text-zinc-100 transition-colors">
            Keahlian
          </a>
          <a href="#kontak" className="hover:text-zinc-100 transition-colors">
            Kontak
          </a>
        </nav>

        {/* Zone 3: Actions */}
        <div className="flex items-center gap-3">
          <button
            onClick={onToggleTheme}
            className="p-2 text-zinc-400 hover:text-zinc-100 bg-zinc-900 border border-zinc-800 rounded-lg transition-colors"
            title={isDark ? 'Mode Terang' : 'Mode Gelap'}
            aria-label="Toggle theme"
          >
            {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
          </button>

          <a
            href="#kontak"
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-zinc-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors"
          >
            <Mail className="w-3.5 h-3.5" />
            <span>Hubungi</span>
          </a>
        </div>
      </div>
    </header>
  );
};
