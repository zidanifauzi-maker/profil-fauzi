import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="py-8 text-center text-xs text-zinc-500">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div>
          © {new Date().getFullYear()} Zidani Fauzi. Semua hak cipta dilindungi.
        </div>
        <div>
          Dibuat dengan React & Tailwind CSS.
        </div>
      </div>
    </footer>
  );
};
