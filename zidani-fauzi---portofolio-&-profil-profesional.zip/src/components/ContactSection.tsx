import React, { useState } from 'react';
import { Mail, Send, CheckCircle2, Copy, Check, MapPin } from 'lucide-react';
import { PROFILE_INFO } from '../data/profileData';

export const ContactSection: React.FC = () => {
  const [copied, setCopied] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(PROFILE_INFO.email);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !message) return;
    setSubmitted(true);
    setName('');
    setEmail('');
    setMessage('');
  };

  return (
    <section id="kontak" className="py-10 border-b border-zinc-850">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 space-y-6">
        <div>
          <h2 className="text-xl font-bold text-zinc-100">
            Hubungi Saya
          </h2>
          <p className="text-sm text-zinc-400 mt-1">
            Tertarik untuk kolaborasi konten video, sponsorship, kebutuhan kepanitiaan, atau diskusi lainnya? Silakan hubungi saya.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
          {/* Direct email info */}
          <div className="md:col-span-5 p-5 rounded-xl bg-zinc-900/40 border border-zinc-800/80 space-y-4">
            <h3 className="text-sm font-semibold text-zinc-200">
              Kontak Langsung
            </h3>
            
            <p className="text-xs text-zinc-400 leading-relaxed">
              Kirimkan email langsung ke alamat berikut:
            </p>

            <div className="flex items-center justify-between p-3 rounded-lg bg-zinc-950 border border-zinc-850">
              <div className="flex items-center gap-2.5 overflow-hidden">
                <Mail className="w-4 h-4 text-amber-400 shrink-0" />
                <span className="text-xs font-mono text-zinc-200 truncate">{PROFILE_INFO.email}</span>
              </div>
              <button
                onClick={handleCopyEmail}
                className="p-1.5 text-zinc-400 hover:text-amber-400 rounded transition-colors"
                title="Salin email"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>

            <div className="text-xs text-zinc-400 space-y-1.5 pt-1 border-t border-zinc-800/60">
              <div className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-zinc-500" />
                <span>Jember, Jawa Timur (Universitas Jember)</span>
              </div>
              <div>Bstation Ambassador · HIMAHI UNEJ</div>
            </div>
          </div>

          {/* Contact form */}
          <div className="md:col-span-7">
            {submitted ? (
              <div className="p-6 rounded-xl bg-zinc-900/50 border border-emerald-500/30 text-center space-y-2">
                <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
                <div className="text-base font-bold text-zinc-100">Pesan Terkirim!</div>
                <p className="text-xs text-zinc-400">
                  Terima kasih sudah menghubungi. Saya akan segera membalas pesan Anda.
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="mt-3 text-xs text-amber-400 hover:underline"
                >
                  Kirim pesan lain
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-medium text-zinc-300">
                      Nama
                    </label>
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Nama Anda"
                      className="w-full px-3 py-2 rounded-lg bg-zinc-900/80 border border-zinc-800 text-sm text-zinc-100 focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-medium text-zinc-300">
                      Email
                    </label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="email@contoh.com"
                      className="w-full px-3 py-2 rounded-lg bg-zinc-900/80 border border-zinc-800 text-sm text-zinc-100 focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-medium text-zinc-300">
                    Pesan
                  </label>
                  <textarea
                    rows={4}
                    required
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Tuliskan pesan atau keperluan Anda..."
                    className="w-full px-3 py-2 rounded-lg bg-zinc-900/80 border border-zinc-800 text-sm text-zinc-100 focus:outline-none focus:border-amber-400 resize-none"
                  />
                </div>

                <button
                  type="submit"
                  className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-zinc-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Kirim Pesan</span>
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
