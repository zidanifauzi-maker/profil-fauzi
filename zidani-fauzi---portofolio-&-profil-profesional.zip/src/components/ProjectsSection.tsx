import React from 'react';
import { ExternalLink, Video, Eye, ThumbsUp, Users, Film, Printer, Gamepad2, Play } from 'lucide-react';
import { CONTENT_ACCOUNTS, SCRATCH_PROJECTS } from '../data/profileData';

export const ProjectsSection: React.FC = () => {
  return (
    <section id="karya" className="py-10 border-b border-zinc-850">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 space-y-8">
        <div>
          <h2 className="text-xl font-bold text-zinc-100">
            Karya Konten, Program Kerja & Proyek
          </h2>
          <p className="text-xs text-zinc-400 mt-1">
            Kanal video di Bstation, inisiatif unit usaha ekonomi kreatif, serta proyek pembuatan game interaktif.
          </p>
        </div>

        {/* 1. Kanal Kreator Bstation */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 uppercase tracking-wider">
            <Video className="w-4 h-4" />
            <span>Kanal Kreator Bstation (Bilibili)</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {CONTENT_ACCOUNTS.map((acc) => (
              <div
                key={acc.id}
                className="p-5 rounded-xl bg-zinc-900/40 border border-zinc-800/80 flex flex-col justify-between hover:border-zinc-700 transition-colors space-y-4"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-semibold text-amber-400 font-mono">
                      {acc.genre}
                    </span>
                    <Video className="w-3.5 h-3.5 text-zinc-500" />
                  </div>

                  <h3 className="text-sm font-bold text-zinc-100 leading-snug">
                    {acc.accountName}
                  </h3>

                  {/* Metrics Grid */}
                  <div className="grid grid-cols-2 gap-2 p-2.5 rounded-lg bg-zinc-950 border border-zinc-850 text-xs">
                    <div className="flex items-center gap-1.5 text-zinc-300">
                      <Eye className="w-3.5 h-3.5 text-zinc-500" />
                      <span className="font-mono">{acc.views.toLocaleString()}</span> <span className="text-[10px] text-zinc-500">views</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-zinc-300">
                      <ThumbsUp className="w-3.5 h-3.5 text-zinc-500" />
                      <span className="font-mono">{acc.likes}</span> <span className="text-[10px] text-zinc-500">likes</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-zinc-300">
                      <Users className="w-3.5 h-3.5 text-zinc-500" />
                      <span className="font-mono">{acc.followers}</span> <span className="text-[10px] text-zinc-500">followers</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-zinc-300">
                      <Film className="w-3.5 h-3.5 text-zinc-500" />
                      <span className="font-mono">{acc.videosCount}</span> <span className="text-[10px] text-zinc-500">video</span>
                    </div>
                  </div>

                  {/* Video Highlight */}
                  <div className="space-y-1">
                    <div className="text-[11px] font-medium text-zinc-400">
                      Video Unggulan:
                    </div>
                    <p className="text-xs text-zinc-200 line-clamp-2 italic">
                      "{acc.highlightTitle}"
                    </p>
                  </div>
                </div>

                {/* Action Link */}
                <a
                  href={acc.highlightUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center justify-between w-full p-2 text-xs font-semibold text-amber-400 bg-amber-400/10 hover:bg-amber-400/20 border border-amber-400/20 rounded-lg transition-colors"
                >
                  <span>Tonton di Bstation</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            ))}
          </div>
        </div>

        {/* 2. Proyek Game Scratch */}
        <div className="space-y-4 pt-2">
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 uppercase tracking-wider">
            <Gamepad2 className="w-4 h-4" />
            <span>Proyek Game Interaktif di Scratch MIT</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {SCRATCH_PROJECTS.map((proj, i) => (
              <div
                key={proj.id}
                className="p-5 rounded-xl bg-zinc-900/40 border border-zinc-800/80 flex flex-col justify-between hover:border-zinc-700 transition-colors space-y-3"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-zinc-100 flex items-center gap-2">
                      <Gamepad2 className="w-4 h-4 text-amber-400" />
                      <span>{proj.title}</span>
                    </h3>
                    <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/40">
                      Scratch Playable
                    </span>
                  </div>

                  <p className="text-xs text-zinc-300 leading-relaxed">
                    {proj.description}
                  </p>
                </div>

                <a
                  href={proj.url}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center justify-between w-full p-2 text-xs font-semibold text-zinc-200 hover:text-white bg-zinc-950 hover:bg-zinc-800 border border-zinc-800 rounded-lg transition-colors"
                >
                  <span className="flex items-center gap-1.5">
                    <Play className="w-3.5 h-3.5 text-amber-400" />
                    <span>Mainkan Game di Scratch</span>
                  </span>
                  <ExternalLink className="w-3.5 h-3.5 text-zinc-400" />
                </a>
              </div>
            ))}
          </div>
        </div>

        {/* 3. Program Kerja: IR Printing */}
        <div className="p-5 sm:p-6 rounded-xl bg-zinc-900/50 border border-zinc-800 space-y-3">
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 uppercase tracking-wider">
            <Printer className="w-4 h-4" />
            <span>Inisiatif Program Kerja: IR Printing (EKRAF HIMAHI)</span>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <h3 className="text-base font-bold text-zinc-100">
                Layanan Percetakan & Kebutuhan Tugas Mahasiswa Hubungan Internasional
              </h3>
              <p className="text-xs text-zinc-300 leading-relaxed max-w-xl">
                Unit usaha di bawah Divisi Ekonomi Kreatif HIMAHI UNEJ yang melayani print tugas, jilid dokumen ringan, dan pengadaan berkas administrasi organisasi. Telah mendapatkan respon positif dari pelanggan melalui Google Form.
              </p>
            </div>

            <div className="shrink-0 p-3 rounded-lg bg-zinc-950 border border-zinc-800 text-right">
              <div className="text-lg font-bold font-mono text-emerald-400">
                Rp 4.000.000,-
              </div>
              <div className="text-[10px] text-zinc-400">
                Total Pemasukan Kas (6 Bulan)
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
