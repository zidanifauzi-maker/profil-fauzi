import React, { useState } from 'react';
import { Mail, MapPin, Copy, Check, Video, ExternalLink } from 'lucide-react';
import { PROFILE_INFO } from '../data/profileData';

export const Hero: React.FC = () => {
  const [copied, setCopied] = useState(false);

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(PROFILE_INFO.email);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <section className="pt-12 pb-10 border-b border-zinc-850">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        <div className="flex flex-col-reverse sm:flex-row items-start sm:items-center justify-between gap-6 sm:gap-8">
          {/* Bio text */}
          <div className="space-y-3.5 flex-1">
            <div className="flex flex-wrap items-center gap-2 text-xs font-medium">
              <span className="text-amber-400">Mahasiswa Hubungan Internasional</span>
              <span aria-hidden="true" className="text-zinc-600">·</span>
              <span className="text-zinc-300">Universitas Jember</span>
              <span aria-hidden="true" className="text-zinc-600">·</span>
              <span className="flex items-center gap-1 text-zinc-400">
                <MapPin className="w-3.5 h-3.5 text-zinc-500" />
                Jember, Jawa Timur
              </span>
            </div>

            <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-zinc-100">
              {PROFILE_INFO.name}
            </h1>

            <p className="text-base text-zinc-300 leading-relaxed max-w-xl">
              Konten Kreator & Ambassador resmi Bstation, anggota divisi Ekonomi Kreatif (IR Printing) HIMAHI, serta berpengalaman dalam manajemen logistik dan operasional kepanitiaan regional.
            </p>

            {/* Quick Actions */}
            <div className="pt-2 flex flex-wrap items-center gap-3">
              <a
                href="#kontak"
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-zinc-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors"
              >
                <Mail className="w-3.5 h-3.5" />
                <span>Kirim Pesan</span>
              </a>

              <button
                onClick={handleCopyEmail}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-zinc-300 hover:text-white bg-zinc-900 border border-zinc-800 hover:border-zinc-700 rounded-lg transition-colors"
                title="Salin email ke papan klip"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Email Tersalin!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-zinc-400" />
                    <span>{PROFILE_INFO.email}</span>
                  </>
                )}
              </button>

              <a
                href="#karya"
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-zinc-300 hover:text-zinc-100 bg-zinc-900 border border-zinc-800 rounded-lg transition-colors"
              >
                <Video className="w-3.5 h-3.5 text-amber-400" />
                <span>Lihat Kanal Bstation</span>
              </a>
            </div>
          </div>

          {/* Portrait Photo */}
          <div className="shrink-0">
            <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl overflow-hidden border-2 border-zinc-800 shadow-md">
              <img
                src={PROFILE_INFO.heroImage}
                alt={PROFILE_INFO.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-top"
              />
            </div>
          </div>
        </div>

        {/* 4-Item Proof Metrics */}
        <div className="mt-8 pt-6 border-t border-zinc-850/80 grid grid-cols-2 sm:grid-cols-4 gap-4">
          {PROFILE_INFO.metrics.map((m, i) => (
            <div key={i} className="p-3 rounded-lg bg-zinc-900/30 border border-zinc-805">
              <div className="text-lg sm:text-xl font-bold font-mono text-zinc-100 tabular-nums">
                {m.value}
              </div>
              <div className="text-[11px] text-zinc-400 mt-0.5">
                {m.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
