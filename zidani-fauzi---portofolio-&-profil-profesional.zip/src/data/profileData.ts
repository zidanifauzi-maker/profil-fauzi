export interface ContentAccount {
  id: string;
  accountName: string;
  genre: string;
  followers: number;
  views: number;
  likes: number;
  videosCount: number;
  highlightTitle: string;
  highlightUrl: string;
}

export interface ScratchProject {
  id: string;
  title: string;
  url: string;
  description: string;
}

export interface ExperienceData {
  id: string;
  category: 'Kreator Konten & Ambassador' | 'Organisasi Mahasiswa' | 'Kepanitiaan';
  role: string;
  organization: string;
  period: string;
  description: string;
  achievements: string[];
  skills: string[];
}

export const PROFILE_INFO = {
  name: "Zidani Fauzi",
  title: "Mahasiswa Hubungan Internasional Universitas Jember · Konten Kreator & Event Logistics Specialist",
  tagline: "Mahasiswa Hubungan Internasional Universitas Jember dengan spesialisasi manajemen logistik acara regional, staf Ekonomi Kreatif (IR Printing), dan kreator konten digital di Bstation.",
  location: "Jember / Jawa Timur, Indonesia",
  email: "zidanifauzi@gmail.com",
  status: "Terbuka untuk Kolaborasi Kreatif & Manajemen Acara",
  heroImage: "/src/assets/images/hero_zidani_portrait_1792969407464.jpg",
  metrics: [
    { value: "6+", label: "Kepanitiaan & Event Logistik" },
    { value: "3", label: "Kanal Bstation Aktif" },
    { value: "Rp 4 Juta", label: "Omset Penjualan IR Printing" },
    { value: "2", label: "Proyek Game Scratch" },
  ],
};

export const CONTENT_ACCOUNTS: ContentAccount[] = [
  {
    id: "akun-1",
    accountName: "Akun 1 - Gameplay Highlight & Meme",
    genre: "Gaming Highlight & Meme Editing",
    followers: 324,
    views: 4000,
    likes: 892,
    videosCount: 81,
    highlightTitle: "HIGHLIGHT GAMEPLAY TERSINGKAT YANG PERNAH ADA DALAM SEJARAH - BLOODSTRIKE EXE GAMEPLAY",
    highlightUrl: "https://bili.im/nHXwHib",
  },
  {
    id: "akun-2",
    accountName: "Akun 2 - Storytelling & Survival",
    genre: "Gaming Storytelling & Minecraft Adventure",
    followers: 118,
    views: 614,
    likes: 54,
    videosCount: 25,
    highlightTitle: "AKU BERMAIN MINECRAFT SURVIVAL TAPI GAPERNAH TAMAT - MINECRAFT STORYTELLING",
    highlightUrl: "https://bili.im/jbqJpMD",
  },
  {
    id: "akun-3",
    accountName: "Akun 3 - Creative Tutorial",
    genre: "Minecraft Building & Creative Tutorial",
    followers: 115,
    views: 824,
    likes: 80,
    videosCount: 27,
    highlightTitle: "3 KREASI RAK BUKU INI AKAN BUAT RUMAH DI MINECRAFT KALIAN JAUH LEBIH BAIK - MINECRAFT TUTORIAL",
    highlightUrl: "https://bili.im/9lGy6Yi",
  },
];

export const SCRATCH_PROJECTS: ScratchProject[] = [
  {
    id: "scratch-1",
    title: "Game Interaktif Scratch #1",
    url: "https://scratch.mit.edu/projects/1285927551",
    description: "Proyek pemrograman blok visual interaktif berbasis logika logika alur permainan, pengaturan sprite, dan interaksi pengguna di platform Scratch MIT.",
  },
  {
    id: "scratch-2",
    title: "Game Interaktif Scratch #2",
    url: "https://scratch.mit.edu/projects/1286122025",
    description: "Pengembangan game sederhana Scratch yang melatih logika komputasional, deteksi tabrakan (collision detection), dan mekanika permainan dinamis.",
  },
];

export const EXPERIENCES: ExperienceData[] = [
  {
    id: "bstation-creator",
    category: "Kreator Konten & Ambassador",
    role: "Konten Kreator & Brand Ambassador",
    organization: "Bstation (Bilibili)",
    period: "2023 - 2026",
    description: "Mengembangkan ekosistem konten video digital di Bstation dengan 3 kanal berbeda genre (meme, tutorial, gameplay highlight/storytelling) serta mengemban amanah sebagai Brand Ambassador resmi platform.",
    achievements: [
      "Mengelola 3 akun aktif dengan total 5.400+ tayangan, 1.000+ likes, dan 130+ video terbit.",
      "Kanal Gameplay Highlight mencapai 4.000 penayangan, 892 likes, dan 324 pengikut setia.",
      "Menjadi Ambassador resmi aplikasi Bstation periode 2024 - 2026.",
      "Berhasil mencari dan merekrut 3 orang untuk menjadi konten kreator baru di platform Bstation.",
    ],
    skills: ["Video Production", "CapCut", "Canva", "Storytelling", "Talent Scouting", "Community Management"],
  },
  {
    id: "himahi-ekraf",
    category: "Organisasi Mahasiswa",
    role: "Anggota Divisi Ekonomi Kreatif (EKRAF) - Dept. Layanan & Jasa",
    organization: "HIMAHI Universitas Jember",
    period: "2026",
    description: "Mengelola program kerja unggulan 'IR Printing', yaitu unit usaha percetakan yang menyediakan layanan print kebutuhan administrasi organisasi serta tugas akademik mahasiswa Hubungan Internasional.",
    achievements: [
      "Memimpin operasional percetakan hingga memperoleh ratusan orderan selama 6 bulan masa layanan.",
      "Membukukan pemasukan kas bersih sebesar Rp 4.000.000,- selama 6 bulan.",
      "Mendapatkan respon dan testimoni positif dari para pelanggan mahasiswa melalui evaluasi Google Form.",
      "Berhasil memfasilitasi kebutuhan berkas administrasi organisasi dan tugas harian perkuliahan mahasiswa.",
      "Mampu mengoperasikan printer dan melakukan teknik penjilidan ringan secara mandiri.",
    ],
    skills: ["IR Printing", "Alur Kas (Cashflow Excel)", "Operasional Printer", "Penjilidan Ringan", "Pelayanan Pelanggan (Google Form)"],
  },
  {
    id: "social-responsibility-2026",
    category: "Kepanitiaan",
    role: "Staff Divisi Logistik",
    organization: "SOCIAL RESPONSIBILITY 2026 - HIMAHI UNEJ",
    period: "2026",
    description: "Program kerja eksternal HIMAHI UNEJ berupa kegiatan volunteer sosial di area Jember, mencakup aksi bakti sosial ke panti jompo, TPQ (Taman Pendidikan Al-Qur'an), serta kegiatan konservasi bersih pantai.",
    achievements: [
      "Mempersiapkan seluruh kebutuhan logistik bakti sosial, peralatan bersih pantai, dan kebutuhan donasi.",
      "Menyusun master list barang lintas divisi, pengadaan barang (beli, sewa, dan pinjam) secara efisien.",
      "Mengoordinasikan penempatan barang di lokasi panti jompo, TPQ, dan area pesisir pantai.",
      "Mengawasi ketersediaan serta memastikan pengembalian barang sewa/pinjam dalam kondisi utuh.",
    ],
    skills: ["Logistik Aksi Sosial", "Volunteer Management", "Koordinasi Penempatan Lapangan", "Inventarisasi"],
  },
  {
    id: "iregeneration-2026",
    category: "Kepanitiaan",
    role: "Staff Divisi Logistik",
    organization: "IREGENERATION 2026 - HIMAHI UNEJ",
    period: "2026",
    description: "Kepanitiaan orientasi studi dan pengenalan jurusan (ospek jurusan) mahasiswa baru Hubungan Internasional Universitas Jember angkatan 2026.",
    achievements: [
      "Mempersiapkan seluruh sarana, prasarana, dan peralatan penunjang masa orientasi jurusan.",
      "Menyusun list kebutuhan logistik terintegrasi untuk seluruh divisi panitia.",
      "Mengurus pengadaan barang (beli, sewa, pinjam) dan mengoperasikan perlengkapan teknis selama acara.",
      "Melakukan cross-check kondisi fisik barang dan menuntaskan pengembalian barang pinjaman.",
    ],
    skills: ["Logistik Acara Mahasiswa Baru", "Operasional Venue", "Pengecekan Fisik Barang", "Manajemen Waktu"],
  },
  {
    id: "irl-2026",
    category: "Kepanitiaan",
    role: "Staff Divisi Logistik",
    organization: "IRL (International Relations League) 2026 - HIMAHI",
    period: "2026",
    description: "Penyelenggaraan ajang perlombaan non-akademik tahunan mahasiswa Hubungan Internasional Universitas Jember periode 2026.",
    achievements: [
      "Mempersiapkan seluruh kebutuhan barang dan instrumen perlombaan non-akademik.",
      "Menyediakan daftar master list barang per divisi panitia untuk pengadaan terpusat.",
      "Mencari barang kebutuhan melalui mekanisme pembelian, persewaan, maupun peminjaman antar unit.",
      "Menangani pengoperasian alat saat perlombaan dan menyelesaikan pengembalian barang sewa/pinjam secara tertib.",
    ],
    skills: ["Logistik Perlombaan", "Pengadaan (Beli/Sewa/Pinjam)", "Alat Teknis", "Time Management"],
  },
  {
    id: "munschool",
    category: "Kepanitiaan",
    role: "Staff Divisi Logistik",
    organization: "MUNSCHOOL - Divisi PSDM HIMAHI UNEJ",
    period: "2025 - 2026",
    description: "Kegiatan kepanitiaan oleh Divisi Pengembangan Sumber Daya Manusia (PSDM) HIMAHI UNEJ yang berfokus pada mentoring dan simulasi Sidang Umum Perserikatan Bangsa-Bangsa (Model United Nations).",
    achievements: [
      "Mempersiapkan seluruh tata letak ruang sidang simulasi PBB, mikrofon, proyektor, dan perlengkapan delegasi.",
      "Menyusun list barang kebutuhan divisi acara, narasumber, dan peserta simulasi.",
      "Pengadaan barang melalui sistem sewa dan pinjam fasilitas universitas.",
      "Mengoperasikan perangkat teknis sidang dan memastikan seluruh inventaris kembali sesuai kondisi semula.",
    ],
    skills: ["Model United Nations (MUN) Setup", "Tata Kelola Ruang Sidang", "Logistik Acara Akademik", "Pengoperasian Audio Visual"],
  },
  {
    id: "hi-cup-2025",
    category: "Kepanitiaan",
    role: "Staff Divisi Logistik",
    organization: "HI CUP 2025 - HIMAHI Universitas Jember",
    period: "2025",
    description: "Turnamen olahraga basket bergengsi se-Jawa Timur yang diselenggarakan oleh HIMAHI Universitas Jember dan diikuti oleh berbagai universitas di Jawa Timur.",
    achievements: [
      "Mempersiapkan kebutuhan peralatan pertandingan lapangan, meja wasit, dan perlengkapan peserta se-Jawa Timur.",
      "Mengoordinasikan pengadaan peralatan (beli, sewa, pinjam) dalam skala turnamen regional.",
      "Memastikan kesiapan teknis alat pertandingan dan penempatan logistik di GOR berjalan aman.",
      "Mengembalikan seluruh barang sewaan dan pinjaman dengan akurasi 100% tanpa kerusakan.",
    ],
    skills: ["Logistik Olahraga Regional", "Kerjasama Tim", "Ketelitian Inventaris", "Problem Solving"],
  },
  {
    id: "irl-2025",
    category: "Kepanitiaan",
    role: "Staff Divisi Logistik",
    organization: "IRL (International Relations League) 2025 - HIMAHI",
    period: "2025",
    description: "Kegiatan perlombaan non-akademik HIMAHI UNEJ periode 2025.",
    achievements: [
      "Menyediakan sistem pendataan list barang untuk seluruh divisi panitia.",
      "Menyediakan barang saat acara berlangsung serta menangani pengoperasian alat teknis.",
      "Mengecek kondisi fisik barang dan menyelesaikan pengembalian barang sewa/pinjam sesuai standar awal.",
    ],
    skills: ["Inventarisasi Barang", "Logistik Acara", "Koordinasi Lintas Divisi"],
  },
];

export const SKILLS_DATA = {
  hardskills: [
    {
      title: "Penyusunan Arus Kas (Cashflow Excel)",
      desc: "Mampu menyusun, mencatat, dan menganalisis alur keluar-masuknya uang (cashflow) secara rapi dan akurat menggunakan Microsoft Excel.",
    },
    {
      title: "Microsoft Office Suite",
      desc: "Mahir mengoperasikan Microsoft Word (administrasi surat/proposal), Microsoft Excel (analisis data & formula), dan Microsoft PowerPoint (slide presentasi).",
    },
    {
      title: "Desain & Video Editing (Canva & CapCut)",
      desc: "Mampu memproduksi materi visual dan mengedit video kreatif dengan Canva dan CapCut untuk konten promosi dan media sosial.",
    },
    {
      title: "Operasional Alat Percetakan (Printer)",
      desc: "Mampu mengoperasikan berbagai jenis mesin printer dokumen, cetak bolak-balik, perawatan berkala, dan penanganan kertas.",
    },
    {
      title: "Penjilidan Ringan Dokumen",
      desc: "Mampu melakukan penjilidan dokumen, tugas makalah, dan laporan administrasi secara rapi dan presisi untuk kebutuhan mahasiswa.",
    },
    {
      title: "Pemrograman Blok Visual (Scratch MIT)",
      desc: "Memahami logika komputasional dasar, pemrograman alur game sederhana, pengaturan sprite, dan interaksi kontrol di Scratch.",
    },
  ],
  softskills: [
    { name: "Resource Management", desc: "Mampu mengelola dan mengoptimalkan pemanfaatan logistik, anggaran, dan sarana secara efektif." },
    { name: "Skill Kreatif", desc: "Kreativitas dalam ideasi konten, konsep visual yang menarik, dan pendekatan pemecahan masalah." },
    { name: "Critical Thinking", desc: "Mampu menganalisis masalah lapangan dan mencari solusi logis yang efisien." },
    { name: "Public Speaking", desc: "Percaya diri berbicara di depan publik, delegasi, peserta, maupun audiens." },
    { name: "Time Management", desc: "Disiplin membagi waktu antara perkuliahan, kepanitiaan, usaha, dan konten." },
    { name: "Communication", desc: "Komunikasi persuasif dan koordinasi efektif antar divisi serta pihak eksternal." },
    { name: "Basic Editing", desc: "Peka terhadap estetika visual, ritme video, dan tata letak dokumen." },
  ],
};
